function varargout = minDistancePoints(p1, varargin)
%MINDISTANCEPOINTS compute minimal distance between several points
%
%   usage :
%   DIST = minDistancePoints(PTS)
%   Return the minimum distance between all couple of points in PTS. PTS is
%   an array of [NxND] values, N being the number of points and ND the
%   dimension of the points.
%
%   DIST = minDistancePoints(PTS1, PTS2)
%   Computes for each point in PTS1 the minimal distance to every point of
%   PTS2. PTS1 and PTS2 are [NxD] arrays, where N is the number of points,
%   and D is the dimension. Dimension must be the same for both arrays, but
%   number of points can be different.
%   The result is an array the same length as PTS1.
%
%
%   DIST = minDistancePoints(..., NORM)
%   use a user-specified norm. NORM=2 means euclidean norm (the default), 
%   NORM=1 is the Manhattan (or "taxi-driver") distance.
%   Increasing NORM growing up reduces the minimal distance, with a limit
%   to the biggest coordinate difference among dimensions. 
%   
%   [DIST I J] = minDistancePoints(PTS)
%   return indices I and J of the 2 points which are the closest. DIST
%   verifies relation:
%   DIST = distancePoints(PTS(I,:), PTS(J,:));
%
%   [DIST J] = minDistancePoints(PTS1, PTS2, ...)
%   also returns the indices of points which are the closest. J has the
%   same size as DIST. It verifies relation : 
%   DIST(I) = distancePoints(PTS1(I,:), PTS2(J,:));
%
%   Example :
%   % minimal distance between random planar points
%   rand(20,2)*100
%   minDist = minDistancePoints(points);
%
%   % minimal distance between random space points
%   rand(30,3)*100
%   [minDist ind1 ind2] = minDistancePoints(points);
%
%
%   ---------
%
%   author : David Legland 
%   INRA - TPV URPOI - BIA IMASTE
%   created the 15/06/2004.
%

%   HISTORY :
%   22/06/2005 : compute sqrt only at the end (faster), and change
%   behaviour for 2 inputs : compute min distance for each point in PTS1.
%   Also add support for different norms.
%   15/08/2005 : make difference when 1 array or 2 arrays of points
%   25/10/2006 : also returns indices of closest points
%   30/10/2006 : generalize to points of any dimension

% default norm (euclidean)
n = 2;

allPoints = false;

% process input variables
if length(varargin)==1
    var = varargin{1};
    if length(var)>1       
        % specify two arrays of points
        p2 = var;
        allPoints = true;
    else
        % specify array of points and the norm
        n = var;
        p2 = p1;
    end
    
elseif isempty(varargin)
    % specify only one array of points
    p2 = p1;

elseif length(varargin)==2
    % specify two array of points and the norm
    p2 = varargin{1};
    n = varargin{2};
    allPoints = true;
end


% number of points in each array
n1  = size(p1, 1);
n2  = size(p2, 1);
d   = size(p1, 2);

% % compute difference of coordinate for each pair of points
% % Both dx and dy are [n1*n2] arrays.
% dx = repmat(p1(:,1), [1 n2])-repmat(p2(:,1)', [n1 1]);
% dy = repmat(p1(:,2), [1 n2])-repmat(p2(:,2)', [n1 1]);

dist = zeros(n1, n2);
if n==2
    % Compute euclidian distance. this is the default case
    % Compute difference of coordinate for each pair of point ([n1*n2] array)
    % and for each dimension. -> dist is a [n1*n2] array.
    for i=1:d
        dist = dist + (repmat(p1(:,i), [1 n2])-repmat(p2(:,i)', [n1 1])).^2;
    end
% 
% 
%     dist = dx.*dx + dy.*dy;

    % compute minimal distance
    if ~allPoints
        % either on all couple of points
        mat = repmat((1:n1)', [1 n1]);
        ind = mat < mat';
        [minSqDist ind] = min(dist(ind));
    else
        % or for each point of P1
        [minSqDist ind] = min(dist, [], 2);
    end
    minDist = sqrt(minSqDist);
else
    % compute distance using the specified norm.
%    dist = power(abs(dx), n) + power(abs(dy), n);
    for i=1:d
        dist = dist + power((abs(repmat(p1(:,i), [1 n2])-repmat(p2(:,i)', [n1 1]))), n);
    end

    % compute minimal distance
    if ~allPoints
        % either on all couple of points
        mat = repmat((1:n1)', [1 n1]);
        ind = mat < mat';
        [minSqDist ind] = min(dist(ind));
    else
        % or for each point of P1
        [minSqDist ind] = min(dist, [], 2);
    end
    minDist = power(minSqDist, 1/n);
end

if ~allPoints
    % convert index in array to row ad column subindices.
    % This uses the fact that index are sorted in a triangular matrix,
    % with the last index of each column being a so-called triangular
    % number
    ind2 = ceil((-1+sqrt(8*ind+1))/2);
    ind1 = ind - ind2*(ind2-1)/2;
    ind2 = ind2 + 1;
end

% format output depending on number of asked parameters
if nargout<=1
    varargout{1} = minDist;
elseif nargout==2
    % If two arrays are asked, 'ind' is an array of indices, one for each
    % point in PTS1, corresponding to the result in minDist
    varargout{1} = minDist;
    varargout{2} = ind;
elseif nargout==3
    % If only one array is asked, minDist is a scalar, ind1 and ind2 are 2
    % indices corresponding to the closest points.
    varargout{1} = minDist;
    varargout{2} = ind1;
    varargout{3} = ind2;
end
    